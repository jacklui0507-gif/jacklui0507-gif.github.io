import { Link, useRouterState } from "@tanstack/react-router";

const ITEMS = [
  { to: "/", label: "陣容" },
  { to: "/matches", label: "賽事紀錄" },
  { to: "/archive", label: "賽事庫" },
  { to: "/stats", label: "數據" },
] as const;

function isHere(path: string, to: string) {
  const clean = path.length > 1 && path.endsWith("/") ? path.slice(0, -1) : path;
  if (to === "/") return clean === "/";
  return clean === to || clean.endsWith(to);
}

export function AppNav() {
  const path = useRouterState({ select: (state) => state.location.pathname });
  return (
    <nav aria-label="頁面" className="flex flex-wrap gap-2">
      {ITEMS.map((item) => {
        const current = isHere(path, item.to);
        return (
          <Link
            key={item.to}
            to={item.to}
            aria-current={current ? "page" : undefined}
            className={
              "inline-flex h-11 items-center rounded-full border px-4 text-sm font-medium " +
              (current ? "border-seal bg-seal-soft text-seal" : "border-line bg-card text-ink")
            }
          >
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}
